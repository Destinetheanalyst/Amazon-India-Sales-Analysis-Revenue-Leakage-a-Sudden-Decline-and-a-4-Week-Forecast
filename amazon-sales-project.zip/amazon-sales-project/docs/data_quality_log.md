# Data Quality Log

Source: Amazon India sales reports (Kaggle). Main file: `Amazon Sale Report.csv`, 128,975 rows, 31 Mar to 29 Jun 2022, currency INR.
Every rule below is implemented in `python/01_clean_data.py` and written to `data/cleaned/data_quality_log.csv`.

## Issues found and how each was handled

| # | Issue | Rows | Decision |
|---|---|---|---|
| 1 | Trailing space in `Sales Channel ` header, empty `Unnamed: 22` column | n/a | Stripped headers, dropped empty column |
| 2 | Exact duplicate order lines | 6 | Dropped, kept first. Tiny impact. They could in theory be genuine repeat lines, so this is documented |
| 3 | Dates in `mm-dd-yy` text | all | Parsed to DATE, added `order_month` |
| 4 | Category case inconsistent (`kurta`) | 49,874 | Title Case |
| 5 | `ship-state`: 69 raw spellings for 36 real states and territories (case, `Rajsthan`, `RJ`, `PB`, `NL`, `Orissa`, `New Delhi`, `Pondicherry`, `APO`...) | 5,064 | Mapped to canonical names |
| 6 | Missing / invalid state | 34 | Labelled `Unknown` (not dropped) |
| 7 | `promotion-ids` long concatenated text | 79,819 populated | Replaced with `has_promotion` flag |
| 8 | `fulfilled-by` duplicates `Fulfilment`. `currency` and `ship-country` are constant | n/a | Dropped |
| 9 | `Amount` is NULL | 7,792 | Set to 0, flagged `amount_was_missing`. 97% are cancelled orders |
| 10 | Completed (shipped/delivered) lines with zero amount | 2,486 | Kept, flagged `zero_value_completed`, excluded from price averages via `priced_units` |
| 11 | `Non-Amazon` sales channel (multi-channel fulfilment) | 124 | Kept. All zero-amount. Excluded from fulfilment analysis |
| 12 | Completed lines with `Qty = 0` | 101 | Kept, contribute no units |
| 13 | SKUs mapping to more than one ASIN | 5 | Most frequent ASIN used |
| 14 | Stock file: rows with no Design No./Stock, 3 exact duplicates, SKU Code containing Excel `#REF!` errors | 36 + 3 | Removed. Stock aggregated by Design No. (style) instead of SKU |
| 15 | Cost/profit not available. SKU formats in the price catalogs do not match Amazon SKUs | n/a | Margin analysis not possible. Project focuses on revenue, leakage, fulfilment and inventory |

## Traps in the data (analysis pitfalls, not cleaning issues)

1. **Returns exist only for Merchant (Easy Ship) orders.** Amazon-fulfilled returns are not in this report, so a 0% return rate for Amazon is a reporting gap. Return rates must not be compared across fulfilment models.
2. **`promotion-ids` is not a valid cause variable.** 98% of cancelled lines carry no promotion ID because it is recorded after confirmation. A naive comparison shows 0.4% cancellations with a promotion vs 37% without. That is an artifact.
3. **Promotion price gap is category mix.** Overall, promoted lines look about ₹90 more expensive per unit, but within each category the gap is near zero (Set: ₹850 vs ₹856).
4. **Partial days.** 31 Mar (171 lines) and 29 Jun (658 lines vs ~1,200 typical). Growth comparisons use 1 Apr to 28 Jun.
5. **Multi-line orders.** 8,597 repeated Order IDs are multi-item orders, not duplicates. Order counts use `COUNT(DISTINCT order_id)`.

## Reconciliation totals (your Excel pivot must match these)

| Measure | Value |
|---|---|
| Order lines (after dedupe) | 128,969 |
| Distinct orders | 120,378 |
| Gross booked amount (all statuses) | ₹78,590,043.30 |
| Cancelled | ₹6,919,284.30 (18,329 lines) |
| Returned | ₹1,384,559 (2,109 lines) |
| Pending | ₹622,409 (939 lines) |
| Lost/Damaged | ₹3,133 (6 lines) |
| **Net revenue (Completed)** | **₹69,660,658.00 (107,586 lines)** |
