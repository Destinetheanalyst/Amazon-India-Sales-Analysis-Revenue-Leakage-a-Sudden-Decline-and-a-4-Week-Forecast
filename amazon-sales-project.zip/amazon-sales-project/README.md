# Amazon India Sales Performance and Revenue Leakage Analysis

**Tools:** Excel (validation) | SQL / MySQL 8.0+ (modeling and analysis) | Python (cleaning, forecasting) | Power BI (dashboard)

## Business problem
A fashion seller on Amazon India needs to know where revenue comes from, where it leaks away
(cancellations, returns), why daily revenue is falling, and which best sellers are about to run out of stock.

## Data
Amazon India sales report, 128,975 order lines, 31 Mar to 29 Jun 2022 (INR), plus a stock snapshot by style.
The data has **no cost or profit column**, so this is a revenue, leakage and operations analysis, not a margin analysis.
See [`docs/data_quality_log.md`](docs/data_quality_log.md) for 15 issues found and how each was handled.

## Metric definitions
| Metric | Definition |
|---|---|
| Gross booked | Sum of `amount` across all order lines |
| Net revenue | `amount` on lines with status group **Completed** (shipped, delivered, out for delivery) |
| Leakage % | (Cancelled + Returned + Lost) value / Gross booked |
| Average price per unit | Net revenue / priced units (zero-value lines excluded) |

## Data model (star schema)
`fact_orders` (one row per order line) joined to `dim_products`, `dim_state` (with zone), `dim_date`; `stock_by_style` joins through `dim_products.style`.

## Project structure
```
python/01_clean_data.py       cleaning + star schema build (fully documented rules)
sql/01_schema.sql             MySQL tables, primary and foreign keys, indexes
sql/02_load_data.sql          LOAD DATA steps + verification checks
sql/03_analysis_queries.sql   20 analytical queries (CTEs, window functions, joins)
data/cleaned/                 analysis-ready CSVs
docs/data_quality_log.md      issues, decisions, reconciliation totals
```

## How to run (MySQL 8.0+)
1. `pip install pandas`, put the raw CSVs in `data/raw/`, run `python python/01_clean_data.py` (or use the ready-made files in `data/cleaned/`).
2. In MySQL Workbench run `sql/01_schema.sql`, then `sql/02_load_data.sql` (edit the folder path first and read STEP 0 for enabling `LOCAL INFILE`).
3. Confirm the verify query returns 128,969 lines and 69,660,658.00 net revenue, then run `sql/03_analysis_queries.sql` one query at a time.

## Key findings so far (SQL phase)
1. **Gross booked ₹78.6M became ₹69.7M net revenue (88.6%).** Cancellations cost ₹6.9M (8.8% of gross), returns ₹1.4M (1.8%).
2. **Daily revenue is falling.** Net revenue per day dropped from about ₹856K in April to ₹726K in June (-15%).
3. **The decline is concentrated, not general.** Comparing April to late June per day: Sets -26%, Kurtas -13%, Tops -14%, while **Western Dress grew +35%**. The South zone held nearly flat (-4%); every other zone fell 19 to 29%.
4. **Two categories carry the business.** Sets (49.9%) and Kurtas (27.2%) make 77% of net revenue. Sets sell at ₹851 per unit vs ₹464 for Kurtas.
5. **Revenue is concentrated.** 325 of 1,368 styles (24%) generate 80% of revenue. The top 5 states generate 56% of revenue and the South zone alone 40%.
6. **Merchant-fulfilled (Easy Ship) orders cancel more:** 17.5% of lines vs 12.8% for Amazon-fulfilled. 6.6% of Easy Ship shipped lines are returned.
7. **Stock-out risk on top sellers.** The #1 style (JNE3797, 3.5% of revenue) has about 3.5 days of stock cover at its sales rate, and several other top-15 styles have under a week. Meanwhile 280 styles hold stock but sold nothing, and the top 15 of them hold 174 to 488 units each.
8. **B2B is negligible** (0.8% of revenue).

## Caveats
- Only 3 months of data, so no year-over-year or seasonality conclusions.
- Return data exists only for Merchant orders (see the data quality log).
- Stock is a snapshot of unknown date; days of cover is an estimate.

## Excel validation (Phase 1)
Open `fact_orders.csv`, build a pivot of Amount and Net Revenue by `status_group`, and confirm it matches the reconciliation table in the data quality log. Repeat for revenue by category after a lookup to `dim_products`.

## Next steps
- [ ] Python: outlier checks, 4-week daily forecast, driver analysis of the decline
- [ ] Power BI: 3-page dashboard (Executive, Product/Region, Leakage and Inventory)
- [ ] Recommendations slide and dashboard screenshots in `images/`
