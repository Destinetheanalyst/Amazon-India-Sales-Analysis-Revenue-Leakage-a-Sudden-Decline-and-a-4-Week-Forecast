Place the raw Kaggle CSVs here (not committed, 69 MB main file):
Amazon Sale Report.csv, Sale Report.csv (stock), and the other files from the archive.
Dataset: "Amazon Sales Report" on Kaggle (Amazon India fashion sales, Apr-Jun 2022).
