-- =====================================================================
-- 02_load_data.sql  |  Load the cleaned CSVs into MySQL 8.0+
-- Load in this order: dim_date, dim_state, dim_products, stock_by_style, fact_orders
-- =====================================================================
USE amazon_sales;

-- ---------------------------------------------------------------------
-- STEP 0 (one time): allow LOAD DATA LOCAL INFILE
--   1) On the server, run as an admin:   SET GLOBAL local_infile = 1;
--   2) In MySQL Workbench: Database > Manage Connections > select your connection >
--      Advanced tab > in "Others" add:   OPT_LOCAL_INFILE=1    then reconnect.
--   (mysql command line: start it with  mysql --local-infile=1 -u root -p )
--   Error 3948 / 2068 "Loading local data is disabled" means step 1 or 2 is missing.
--
-- STEP 1: replace  C:/path/to/amazon-sales-project  below with YOUR folder.
--   Use FORWARD slashes even on Windows.  Example: C:/Users/Ada/amazon-sales-project
-- ---------------------------------------------------------------------

LOAD DATA LOCAL INFILE 'C:/path/to/amazon-sales-project/data/cleaned/dim_date.csv'
INTO TABLE dim_date
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'C:/path/to/amazon-sales-project/data/cleaned/dim_state.csv'
INTO TABLE dim_state
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'C:/path/to/amazon-sales-project/data/cleaned/dim_products.csv'
INTO TABLE dim_products
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'C:/path/to/amazon-sales-project/data/cleaned/stock_by_style.csv'
INTO TABLE stock_by_style
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- city and postal_code are blank in 33 rows. MySQL would load blanks as empty
-- strings, not NULL, so they are read into variables and converted with NULLIF.
LOAD DATA LOCAL INFILE 'C:/path/to/amazon-sales-project/data/cleaned/fact_orders.csv'
INTO TABLE fact_orders
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(order_line_id, order_id, order_date, order_month, status, status_group, fulfilment,
 ship_service_level, sales_channel, courier_status, is_b2b, sku, state, @city, @postal_code,
 qty, amount, net_units, priced_units, net_revenue, has_promotion, amount_was_missing,
 zero_value_completed)
SET city        = NULLIF(@city, ''),
    postal_code = NULLIF(@postal_code, '');

-- If you re-saved a CSV in Excel on Windows, its line endings become \r\n:
-- change LINES TERMINATED BY '\n' to '\r\n' for that file.

-- ---------------------------------------------------------------------
-- Fallback if LOCAL INFILE is blocked (e.g. a managed server):
-- Workbench > right-click the table > Table Data Import Wizard > pick the CSV.
-- It works, but is slow for fact_orders (about 129K rows, can take 10+ minutes).
-- For fact_orders the wizard loads blanks as '' so run this afterwards:
--   UPDATE fact_orders SET city = NULL WHERE city = '';
--   UPDATE fact_orders SET postal_code = NULL WHERE postal_code = '';
-- ---------------------------------------------------------------------

-- ---------------------------------------------------------------------
-- VERIFY (all four must match, or something loaded wrongly)
-- ---------------------------------------------------------------------
SELECT COUNT(*)         AS order_lines,   -- 128969
       SUM(amount)      AS gross_booked,  -- 78590043.30
       SUM(net_revenue) AS net_revenue,   -- 69660658.00
       SUM(city IS NULL) AS null_city     -- 33
FROM fact_orders;
SHOW WARNINGS;   -- should be empty
